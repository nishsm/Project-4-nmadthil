/**
 * Author: Nishanth Madthila
 * Andrew ID: nmadthil
 *
 * MainActivity — the only activity in the Trivia Quiz Android app.
 *
 * Views used (satisfies "at least 3 different kinds of Views"):
 *   - TextView  (title, labels, status message)
 *   - Spinner   (category selector, difficulty selector)
 *   - EditText  (question amount input)
 *   - Button    (fetch button)
 *   - ListView  (displays trivia questions returned from the web service)
 *
 * Flow:
 *   1. User picks category, difficulty, and amount.
 *   2. "Get Trivia!" button triggers a background network request to the web service.
 *   3. Web service fetches questions from OpenTDB and returns filtered JSON.
 *   4. Results are displayed in the ListView.  The app is fully repeatable.
 */

package edu.cmu.cs.nmadthil.trivia;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    // -----------------------------------------------------------------------
    // TODO: Replace this URL with your GitHub Codespaces URL after deploying.
    //       Example: "https://laughing-space-xyz-8080.app.github.dev/trivia"
    // -----------------------------------------------------------------------
    private static final String WEB_SERVICE_URL = "https://potential-meme-pwp76vrvgp72675v-8080.app.github.dev/trivia";

    // Category display names and corresponding OpenTDB IDs (0 = any)
    private static final String[] CATEGORY_NAMES = {
        "Any Category", "General Knowledge", "Science & Nature",
        "Science: Computers", "Sports", "Geography", "History", "Art"
    };
    private static final int[] CATEGORY_IDS = { 0, 9, 17, 18, 21, 22, 23, 25 };

    // Views
    private Spinner      categorySpinner;
    private Spinner      difficultySpinner;
    private EditText     amountEditText;
    private Button       fetchButton;
    private TextView     statusText;
    private ListView     questionsListView;

    // Data
    private final List<JSONObject> questions = new ArrayList<>();
    private TriviaAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind views
        categorySpinner   = findViewById(R.id.categorySpinner);
        difficultySpinner = findViewById(R.id.difficultySpinner);
        amountEditText    = findViewById(R.id.amountEditText);
        fetchButton       = findViewById(R.id.fetchButton);
        statusText        = findViewById(R.id.statusText);
        questionsListView = findViewById(R.id.questionsListView);

        // Category spinner
        ArrayAdapter<String> catAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_item, CATEGORY_NAMES);
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(catAdapter);

        // Difficulty spinner
        String[] difficulties = {"Any Difficulty", "Easy", "Medium", "Hard"};
        ArrayAdapter<String> diffAdapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_item, difficulties);
        diffAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        difficultySpinner.setAdapter(diffAdapter);

        // ListView adapter
        adapter = new TriviaAdapter(this, questions);
        questionsListView.setAdapter(adapter);

        fetchButton.setOnClickListener(v -> fetchTrivia());
    }

    /** Validate inputs, build URL, and fire a background network request. */
    private void fetchTrivia() {
        // Validate amount
        String amountStr = amountEditText.getText().toString().trim();
        if (amountStr.isEmpty()) amountStr = "5";
        int amount;
        try {
            amount = Integer.parseInt(amountStr);
            if (amount < 1 || amount > 50) {
                statusText.setText("Amount must be between 1 and 50.");
                return;
            }
        } catch (NumberFormatException e) {
            statusText.setText("Please enter a valid number for amount.");
            return;
        }

        int categoryId = CATEGORY_IDS[categorySpinner.getSelectedItemPosition()];

        // Map spinner position to difficulty query param ("" means any)
        String[] diffValues = {"", "easy", "medium", "hard"};
        String difficulty = diffValues[difficultySpinner.getSelectedItemPosition()];

        // Build request URL
        StringBuilder urlBuilder = new StringBuilder(WEB_SERVICE_URL);
        urlBuilder.append("?amount=").append(amount);
        if (categoryId > 0)          urlBuilder.append("&category=").append(categoryId);
        if (!difficulty.isEmpty())   urlBuilder.append("&difficulty=").append(difficulty);
        final String url = urlBuilder.toString();

        // Optimistic UI update
        fetchButton.setEnabled(false);
        statusText.setText("Loading\u2026");
        questions.clear();
        adapter.notifyDataSetChanged();

        // Network call on a background thread; UI update back on main thread
        new Thread(() -> {
            String responseBody = null;
            String networkError = null;
            try {
                responseBody = fetchUrl(url);
            } catch (Exception e) {
                networkError = "Network error: " + e.getMessage();
            }

            final String body  = responseBody;
            final String error = networkError;

            runOnUiThread(() -> {
                fetchButton.setEnabled(true);
                if (error != null) {
                    statusText.setText(error);
                    return;
                }
                try {
                    JSONObject json = new JSONObject(body);
                    if ("error".equals(json.getString("status"))) {
                        statusText.setText(json.getString("message"));
                        return;
                    }
                    JSONArray arr = json.getJSONArray("questions");
                    questions.clear();
                    for (int i = 0; i < arr.length(); i++) {
                        questions.add(arr.getJSONObject(i));
                    }
                    adapter.notifyDataSetChanged();
                    statusText.setText("Loaded " + questions.size() + " question(s). Tap Get Trivia! to refresh.");
                } catch (JSONException e) {
                    statusText.setText("Error parsing server response: " + e.getMessage());
                }
            });
        }).start();
    }

    /** Perform a synchronous HTTP GET and return the response body. */
    private String fetchUrl(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(10_000);
        conn.setReadTimeout(15_000);

        int code = conn.getResponseCode();
        InputStream stream = (code >= 400) ? conn.getErrorStream() : conn.getInputStream();

        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder  sb     = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        conn.disconnect();
        return sb.toString();
    }
}
