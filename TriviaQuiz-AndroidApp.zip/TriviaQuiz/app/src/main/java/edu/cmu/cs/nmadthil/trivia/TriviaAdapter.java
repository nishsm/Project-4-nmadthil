/**
 * Author: Nishanth Madthila
 * Andrew ID: nmadthil
 *
 * TriviaAdapter — custom BaseAdapter that renders each trivia question
 * returned by the web service into an item_trivia.xml view.
 */

package edu.cmu.cs.nmadthil.trivia;

import android.content.Context;
import android.view.*;
import android.widget.BaseAdapter;
import android.widget.TextView;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.List;

public class TriviaAdapter extends BaseAdapter {

    private final Context          context;
    private final List<JSONObject> questions;

    public TriviaAdapter(Context context, List<JSONObject> questions) {
        this.context   = context;
        this.questions = questions;
    }

    @Override public int    getCount()                { return questions.size(); }
    @Override public Object getItem(int position)     { return questions.get(position); }
    @Override public long   getItemId(int position)   { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.item_trivia, parent, false);
        }

        TextView questionNumText = convertView.findViewById(R.id.questionNum);
        TextView questionText    = convertView.findViewById(R.id.questionText);
        TextView metaText        = convertView.findViewById(R.id.metaText);
        TextView answerText      = convertView.findViewById(R.id.answerText);

        try {
            JSONObject q = questions.get(position);
            questionNumText.setText("Q" + (position + 1));
            questionText.setText(q.getString("question"));
            // Category and difficulty from the web service (already HTML-decoded)
            String category   = q.getString("category");
            String difficulty = q.getString("difficulty");
            metaText.setText(category + " \u2022 " + capitalize(difficulty));
            answerText.setText("\u2714 " + q.getString("answer"));
        } catch (JSONException e) {
            questionText.setText("Error loading question.");
        }

        return convertView;
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
