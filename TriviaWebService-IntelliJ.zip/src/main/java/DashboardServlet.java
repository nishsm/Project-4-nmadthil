/**
 * Author: Nishanth Madthila
 * Andrew ID: nmadthil
 *
 * DashboardServlet — serves the operations dashboard at /dashboard.
 *
 * Queries MongoDB for analytics and full request logs, sets them as
 * request attributes, then forwards to dashboard.jsp for rendering.
 * Dashboard interactions are NOT logged to MongoDB (only mobile requests are).
 */

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import org.bson.Document;

@WebServlet(name = "DashboardServlet", urlPatterns = {"/dashboard"})
public class DashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            MongoDBClient db = MongoDBClient.getInstance();

            // Analytics queries
            List<Document> topCategories = db.getTopCategories();
            List<Document> topDevices    = db.getTopDevices();
            double avgResponseTime       = db.getAverageResponseTime();
            long   totalRequests         = db.getTotalRequests();
            long   totalQuestionsServed  = db.getTotalQuestionsServed();

            // Full logs (most recent 50)
            List<Document> logs = db.getLogs();

            // Pass to JSP
            request.setAttribute("topCategories",       topCategories);
            request.setAttribute("topDevices",          topDevices);
            request.setAttribute("avgResponseTime",     String.format("%.1f", avgResponseTime));
            request.setAttribute("totalRequests",       totalRequests);
            request.setAttribute("totalQuestionsServed", totalQuestionsServed);
            request.setAttribute("logs",                logs);

            RequestDispatcher dispatcher = request.getRequestDispatcher("/dashboard.jsp");
            dispatcher.forward(request, response);

        } catch (Exception e) {
            response.setContentType("text/html");
            response.getWriter().println(
                "<h1>Dashboard Error</h1><p>" + e.getMessage() + "</p>"
            );
        }
    }
}
