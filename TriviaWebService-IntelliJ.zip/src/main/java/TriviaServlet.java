/**
 * Author: Nishanth Madthila
 * Andrew ID: nmadthil
 *
 * TriviaServlet — the main API endpoint for the Android app.
 *
 * Endpoint: GET /trivia
 * Query parameters:
 *   category  (optional) — OpenTDB category ID (int), e.g. 17 for Science & Nature
 *   difficulty (optional) — "easy", "medium", or "hard"
 *   amount    (optional) — number of questions, 1–50 (default 5)
 *
 * Returns a JSON object:
 *   { "status": "success", "questions": [ { "question", "answer", "category", "difficulty" }, ... ] }
 *   { "status": "error",   "message": "..." }
 *
 * Every successful request is logged to MongoDB (8 fields).
 * The dashboard data (separate endpoint /dashboard) is NOT logged here.
 */

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.*;
import java.time.Instant;
import org.json.*;
import org.bson.Document;

@WebServlet(name = "TriviaServlet", urlPatterns = {"/trivia"})
public class TriviaServlet extends HttpServlet {

    private static final String OPENTDB_URL = "https://opentdb.com/api.php";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Access-Control-Allow-Origin", "*");

        // --- Parse parameters ---
        String categoryParam  = request.getParameter("category");
        String difficulty     = request.getParameter("difficulty");
        String amountParam    = request.getParameter("amount");
        String userAgent      = request.getHeader("User-Agent");
        String ipAddress      = request.getRemoteAddr();

        // Validate amount (default 5, range 1–50)
        int amount = 5;
        if (amountParam != null && !amountParam.isEmpty()) {
            try {
                amount = Integer.parseInt(amountParam);
                if (amount < 1 || amount > 50) {
                    sendError(response, "Amount must be between 1 and 50.");
                    return;
                }
            } catch (NumberFormatException e) {
                sendError(response, "Invalid amount parameter. Must be an integer.");
                return;
            }
        }

        // Validate difficulty
        if (difficulty != null && !difficulty.isEmpty()
                && !difficulty.equals("easy")
                && !difficulty.equals("medium")
                && !difficulty.equals("hard")) {
            sendError(response, "Invalid difficulty. Use: easy, medium, or hard.");
            return;
        }

        // Validate category
        int    categoryId   = 0;
        String categoryName = "Any";
        if (categoryParam != null && !categoryParam.isEmpty()) {
            try {
                categoryId   = Integer.parseInt(categoryParam);
                categoryName = getCategoryName(categoryId);
            } catch (NumberFormatException e) {
                sendError(response, "Invalid category ID. Must be an integer.");
                return;
            }
        }

        // --- Build OpenTDB request URL ---
        StringBuilder apiUrlBuilder = new StringBuilder(OPENTDB_URL + "?type=multiple");
        apiUrlBuilder.append("&amount=").append(amount);
        if (categoryId > 0)                             apiUrlBuilder.append("&category=").append(categoryId);
        if (difficulty != null && !difficulty.isEmpty()) apiUrlBuilder.append("&difficulty=").append(difficulty);

        // --- Call OpenTDB ---
        long   apiStart = System.currentTimeMillis();
        String apiResponse;
        try {
            apiResponse = fetchUrl(apiUrlBuilder.toString());
        } catch (Exception e) {
            sendError(response, "Could not reach the trivia API. Please try again later.");
            return;
        }
        long apiResponseTimeMs = System.currentTimeMillis() - apiStart;

        // --- Parse OpenTDB response ---
        JSONObject apiJson;
        try {
            apiJson = new JSONObject(apiResponse);
        } catch (JSONException e) {
            sendError(response, "Received invalid data from the trivia API.");
            return;
        }

        int apiCode = apiJson.getInt("response_code");
        switch (apiCode) {
            case 1: sendError(response, "Not enough questions for that combination. Try fewer questions or a different category."); return;
            case 2: sendError(response, "Invalid parameters sent to the trivia API."); return;
            case 5: sendError(response, "Rate limited by the trivia API. Please wait a moment and try again."); return;
            default:
                if (apiCode != 0) { sendError(response, "Trivia API error (code " + apiCode + ")."); return; }
        }

        // --- Build filtered response (only what the Android app needs) ---
        JSONArray rawResults = apiJson.getJSONArray("results");
        JSONArray questions  = new JSONArray();

        for (int i = 0; i < rawResults.length(); i++) {
            JSONObject raw = rawResults.getJSONObject(i);
            JSONObject q   = new JSONObject();
            q.put("question",   decodeHtml(raw.getString("question")));
            q.put("answer",     decodeHtml(raw.getString("correct_answer")));
            q.put("category",   decodeHtml(raw.getString("category")));
            q.put("difficulty", raw.getString("difficulty"));
            questions.put(q);
        }

        JSONObject result = new JSONObject();
        result.put("status",    "success");
        result.put("questions", questions);

        // --- Log to MongoDB (8 fields) ---
        try {
            Document log = new Document()
                .append("timestamp",        Instant.now().toString())       // 1. when
                .append("deviceModel",      parseDeviceModel(userAgent))    // 2. phone model
                .append("ipAddress",        ipAddress)                      // 3. client IP
                .append("category",         categoryName)                   // 4. category requested
                .append("difficulty",       difficulty != null && !difficulty.isEmpty() ? difficulty : "any") // 5. difficulty
                .append("amount",           amount)                         // 6. questions requested
                .append("apiResponseTimeMs", apiResponseTimeMs)             // 7. OpenTDB latency
                .append("questionsReturned", questions.length());           // 8. questions actually returned
            MongoDBClient.getInstance().insertLog(log);
        } catch (Exception e) {
            // Logging failure should not break the API response
            System.err.println("[TriviaServlet] MongoDB logging error: " + e.getMessage());
        }

        // --- Send response ---
        response.getWriter().print(result.toString());
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /** Make an HTTP GET request and return the response body as a String. */
    private String fetchUrl(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(10000);

        if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
            throw new IOException("HTTP " + conn.getResponseCode());
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder  sb     = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        conn.disconnect();
        return sb.toString();
    }

    /** Write a JSON error response. */
    private void sendError(HttpServletResponse response, String message) throws IOException {
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        JSONObject err = new JSONObject();
        err.put("status",  "error");
        err.put("message", message);
        response.getWriter().print(err.toString());
    }

    /**
     * Decode common HTML entities returned by OpenTDB so the Android app
     * receives clean plain text without doing any extra processing.
     */
    private String decodeHtml(String html) {
        return html
            .replace("&amp;",   "&")
            .replace("&lt;",    "<")
            .replace("&gt;",    ">")
            .replace("&quot;",  "\"")
            .replace("&#039;",  "'")
            .replace("&ldquo;", "\u201C")
            .replace("&rdquo;", "\u201D")
            .replace("&lsquo;", "\u2018")
            .replace("&rsquo;", "\u2019")
            .replace("&eacute;","é")
            .replace("&ntilde;","ñ")
            .replace("&ouml;",  "ö")
            .replace("&uuml;",  "ü")
            .replace("&auml;",  "ä");
    }

    /**
     * Extract the device model from an Android User-Agent string.
     * Android UA format: "Dalvik/... (Linux; Android X.X; MODEL Build/...)"
     */
    private String parseDeviceModel(String userAgent) {
        if (userAgent == null) return "Unknown";
        int androidIdx = userAgent.indexOf("Android");
        if (androidIdx == -1) return "Non-Android";
        int modelStart = userAgent.indexOf("; ", androidIdx);
        if (modelStart == -1) return "Unknown";
        modelStart += 2;
        int modelEnd = userAgent.indexOf(" Build/", modelStart);
        if (modelEnd == -1) return userAgent.substring(modelStart);
        return userAgent.substring(modelStart, modelEnd);
    }

    /** Map OpenTDB category IDs to readable names. */
    private String getCategoryName(int id) {
        switch (id) {
            case 9:  return "General Knowledge";
            case 17: return "Science & Nature";
            case 18: return "Science: Computers";
            case 21: return "Sports";
            case 22: return "Geography";
            case 23: return "History";
            case 25: return "Art";
            default: return "Category " + id;
        }
    }
}
