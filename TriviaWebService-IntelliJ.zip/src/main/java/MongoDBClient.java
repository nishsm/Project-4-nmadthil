/**
 * Author: Nishanth Madthila
 * Andrew ID: nmadthil
 *
 * Singleton MongoDB client for Project 4 Task 2.
 * Handles all database operations: inserting request logs and
 * querying analytics data for the dashboard.
 */

import com.mongodb.client.*;
import org.bson.Document;
import java.util.*;

public class MongoDBClient {

    private static final String MONGO_URI =
        "mongodb://nishsm:Nishsm1@ac-vqbbw4w-shard-00-00.8kli7zb.mongodb.net:27017," +
        "ac-vqbbw4w-shard-00-01.8kli7zb.mongodb.net:27017," +
        "ac-vqbbw4w-shard-00-02.8kli7zb.mongodb.net:27017/" +
        "test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";

    private static final String DATABASE_NAME   = "project4task2";
    private static final String COLLECTION_NAME = "requestlogs";

    private static MongoDBClient instance;
    private final MongoCollection<Document> collection;

    private MongoDBClient() {
        MongoClient mongoClient = MongoClients.create(MONGO_URI);
        MongoDatabase database  = mongoClient.getDatabase(DATABASE_NAME);
        collection = database.getCollection(COLLECTION_NAME);
    }

    public static synchronized MongoDBClient getInstance() {
        if (instance == null) {
            instance = new MongoDBClient();
        }
        return instance;
    }

    /** Insert one request log entry. */
    public void insertLog(Document logEntry) {
        collection.insertOne(logEntry);
    }

    /** Return the 50 most recent log entries, newest first. */
    public List<Document> getLogs() {
        List<Document> logs = new ArrayList<>();
        try (MongoCursor<Document> cursor = collection
                .find()
                .sort(new Document("timestamp", -1))
                .limit(50)
                .iterator()) {
            while (cursor.hasNext()) logs.add(cursor.next());
        }
        return logs;
    }

    /** Top 5 most-requested categories. */
    public List<Document> getTopCategories() {
        List<Document> pipeline = Arrays.asList(
            new Document("$group", new Document("_id", "$category")
                .append("count", new Document("$sum", 1))),
            new Document("$sort",  new Document("count", -1)),
            new Document("$limit", 5)
        );
        List<Document> results = new ArrayList<>();
        try (MongoCursor<Document> cursor = collection.aggregate(pipeline).iterator()) {
            while (cursor.hasNext()) results.add(cursor.next());
        }
        return results;
    }

    /** Top 5 Android device models by request count. */
    public List<Document> getTopDevices() {
        List<Document> pipeline = Arrays.asList(
            new Document("$group", new Document("_id", "$deviceModel")
                .append("count", new Document("$sum", 1))),
            new Document("$sort",  new Document("count", -1)),
            new Document("$limit", 5)
        );
        List<Document> results = new ArrayList<>();
        try (MongoCursor<Document> cursor = collection.aggregate(pipeline).iterator()) {
            while (cursor.hasNext()) results.add(cursor.next());
        }
        return results;
    }

    /** Average OpenTDB API response time in milliseconds across all requests. */
    public double getAverageResponseTime() {
        List<Document> pipeline = Collections.singletonList(
            new Document("$group", new Document("_id", null)
                .append("avg", new Document("$avg", "$apiResponseTimeMs")))
        );
        try (MongoCursor<Document> cursor = collection.aggregate(pipeline).iterator()) {
            if (cursor.hasNext()) {
                Object avg = cursor.next().get("avg");
                return avg != null ? ((Number) avg).doubleValue() : 0.0;
            }
        }
        return 0.0;
    }

    /** Total trivia questions served across all requests. */
    public long getTotalQuestionsServed() {
        List<Document> pipeline = Collections.singletonList(
            new Document("$group", new Document("_id", null)
                .append("total", new Document("$sum", "$questionsReturned")))
        );
        try (MongoCursor<Document> cursor = collection.aggregate(pipeline).iterator()) {
            if (cursor.hasNext()) {
                Object total = cursor.next().get("total");
                return total != null ? ((Number) total).longValue() : 0L;
            }
        }
        return 0L;
    }

    /** Total number of requests ever logged. */
    public long getTotalRequests() {
        return collection.countDocuments();
    }
}
