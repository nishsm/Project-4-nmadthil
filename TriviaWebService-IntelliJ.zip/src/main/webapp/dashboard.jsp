<%-- Author: Nishanth Madthila, Andrew ID: nmadthil --%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List, org.bson.Document" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trivia Service Dashboard</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; background: #f0f2f5; color: #333; padding: 24px; }
        h1  { font-size: 26px; color: #2c3e50; border-bottom: 3px solid #3498db;
              padding-bottom: 12px; margin-bottom: 6px; }
        .subtitle { color: #777; font-size: 13px; margin-bottom: 24px; }
        h2  { font-size: 18px; color: #34495e; margin: 28px 0 12px; }

        /* Stat cards */
        .cards { display: flex; gap: 16px; margin-bottom: 8px; flex-wrap: wrap; }
        .card  { background: white; border-radius: 8px; padding: 18px 22px;
                 box-shadow: 0 2px 6px rgba(0,0,0,.1); flex: 1; min-width: 160px; }
        .card-label  { font-size: 12px; text-transform: uppercase; color: #888;
                       letter-spacing: .5px; margin-bottom: 6px; }
        .card-value  { font-size: 30px; font-weight: bold; color: #2c3e50; }
        .card-unit   { font-size: 13px; color: #aaa; margin-top: 2px; }

        /* Tables */
        table { width: 100%; border-collapse: collapse; background: white;
                border-radius: 8px; overflow: hidden;
                box-shadow: 0 2px 6px rgba(0,0,0,.1); margin-bottom: 16px; }
        th  { background: #3498db; color: white; padding: 10px 14px;
              text-align: left; font-size: 13px; font-weight: 600; }
        td  { padding: 9px 14px; border-bottom: 1px solid #ecf0f1; font-size: 13px; }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: #f8f9fa; }
        .empty { text-align: center; color: #aaa; font-style: italic; padding: 20px; }

        /* Difficulty badges */
        .badge { display: inline-block; padding: 2px 9px; border-radius: 12px;
                 font-size: 11px; font-weight: bold; color: white; }
        .easy   { background: #27ae60; }
        .medium { background: #f39c12; }
        .hard   { background: #e74c3c; }
        .any    { background: #95a5a6; }

        .rank { font-weight: bold; color: #3498db; }
        .ts   { font-size: 11px; color: #999; }
    </style>
</head>
<body>

<%
    List<Document> topCategories      = (List<Document>) request.getAttribute("topCategories");
    List<Document> topDevices         = (List<Document>) request.getAttribute("topDevices");
    List<Document> logs               = (List<Document>) request.getAttribute("logs");
    String         avgResponseTime    = (String)         request.getAttribute("avgResponseTime");
    long           totalRequests      = (Long)           request.getAttribute("totalRequests");
    long           totalQsServed      = (Long)           request.getAttribute("totalQuestionsServed");
%>

<h1>Trivia Service &mdash; Operations Dashboard</h1>
<p class="subtitle">Author: Nishanth Madthila &bull; Andrew ID: nmadthil &bull; 95-702 Project 4</p>

<!-- ===== Summary Cards ===== -->
<div class="cards">
    <div class="card">
        <div class="card-label">Total Requests</div>
        <div class="card-value"><%= totalRequests %></div>
        <div class="card-unit">from Android app</div>
    </div>
    <div class="card">
        <div class="card-label">Questions Served</div>
        <div class="card-value"><%= totalQsServed %></div>
        <div class="card-unit">trivia questions total</div>
    </div>
    <div class="card">
        <div class="card-label">Avg OpenTDB Latency</div>
        <div class="card-value"><%= avgResponseTime %></div>
        <div class="card-unit">milliseconds</div>
    </div>
</div>

<!-- ===== Analytics 1: Top Categories ===== -->
<h2>Analytics 1 &mdash; Top Requested Categories</h2>
<table>
    <tr><th>Rank</th><th>Category</th><th>Request Count</th></tr>
    <%
        int rank = 1;
        for (Document cat : topCategories) {
    %>
    <tr>
        <td class="rank">#<%= rank++ %></td>
        <td><%= cat.get("_id") %></td>
        <td><%= ((Number) cat.get("count")).intValue() %></td>
    </tr>
    <% } if (topCategories.isEmpty()) { %>
    <tr><td colspan="3" class="empty">No data yet — use the Android app to generate requests.</td></tr>
    <% } %>
</table>

<!-- ===== Analytics 2: Top Device Models ===== -->
<h2>Analytics 2 &mdash; Top Android Device Models</h2>
<table>
    <tr><th>Rank</th><th>Device Model</th><th>Request Count</th></tr>
    <%
        rank = 1;
        for (Document dev : topDevices) {
    %>
    <tr>
        <td class="rank">#<%= rank++ %></td>
        <td><%= dev.get("_id") %></td>
        <td><%= ((Number) dev.get("count")).intValue() %></td>
    </tr>
    <% } if (topDevices.isEmpty()) { %>
    <tr><td colspan="3" class="empty">No data yet.</td></tr>
    <% } %>
</table>

<!-- ===== Analytics 3: Average API Latency (detail) ===== -->
<h2>Analytics 3 &mdash; OpenTDB API Response Time</h2>
<table>
    <tr><th>Metric</th><th>Value</th></tr>
    <tr><td>Average latency (all requests)</td><td><%= avgResponseTime %> ms</td></tr>
    <tr>
        <td>Slowest request (last 50)</td>
        <td><%
            long maxMs = 0;
            for (Document log : logs) {
                Object t = log.get("apiResponseTimeMs");
                if (t != null) { long v = ((Number)t).longValue(); if (v > maxMs) maxMs = v; }
            }
        %><%= maxMs %> ms</td>
    </tr>
    <tr>
        <td>Fastest request (last 50)</td>
        <td><%
            long minMs = Long.MAX_VALUE;
            for (Document log : logs) {
                Object t = log.get("apiResponseTimeMs");
                if (t != null) { long v = ((Number)t).longValue(); if (v < minMs) minMs = v; }
            }
        %><%= minMs == Long.MAX_VALUE ? "N/A" : minMs + " ms" %></td>
    </tr>
</table>

<!-- ===== Full Request Logs ===== -->
<h2>Full Request Logs <small style="font-size:13px;color:#999;">(most recent 50)</small></h2>
<table>
    <tr>
        <th>#</th>
        <th>Timestamp (UTC)</th>
        <th>Device Model</th>
        <th>IP Address</th>
        <th>Category</th>
        <th>Difficulty</th>
        <th>Requested</th>
        <th>Returned</th>
        <th>API Time (ms)</th>
    </tr>
    <%
        int rowNum = 1;
        for (Document log : logs) {
            String diff = String.valueOf(log.get("difficulty"));
    %>
    <tr>
        <td><%= rowNum++ %></td>
        <td class="ts"><%= log.get("timestamp") %></td>
        <td><%= log.get("deviceModel") %></td>
        <td><%= log.get("ipAddress") %></td>
        <td><%= log.get("category") %></td>
        <td><span class="badge <%= diff %>"><%= diff.toUpperCase() %></span></td>
        <td><%= log.get("amount") %></td>
        <td><%= log.get("questionsReturned") %></td>
        <td><%= log.get("apiResponseTimeMs") %></td>
    </tr>
    <% } if (logs.isEmpty()) { %>
    <tr>
        <td colspan="9" class="empty">
            No requests logged yet. Use the Android app to generate data.
        </td>
    </tr>
    <% } %>
</table>

</body>
</html>
